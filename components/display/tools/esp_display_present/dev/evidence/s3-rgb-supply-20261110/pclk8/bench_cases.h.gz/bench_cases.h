/* Generated from the common case planner; do not edit. */
static const bench_case_t bench_cases[] = {
    {"DOUBLE_FULL",B_DOUBLE_FULL,0,1,0,false,true,"",0},
};
