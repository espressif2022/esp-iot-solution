#pragma once
#include <stdint.h>
#include "esp_err.h"
#include "esp_lcd_panel_ops.h"
#include "esp_lcd_panel_io.h"
#define HW_LCD_H_RES 320
#define HW_LCD_V_RES 240
#define HW_USE_TOUCH 0
#define HW_USE_ENCODER 0
typedef enum {HW_ROTATE_0=0, HW_ROTATE_90=90, HW_ROTATE_180=180, HW_ROTATE_270=270} hw_rotation_t;
esp_err_t hw_lcd_init(esp_lcd_panel_handle_t *, esp_lcd_panel_io_handle_t *, uint8_t, hw_rotation_t);
esp_err_t hw_lcd_deinit(void);
int hw_lcd_get_te_gpio(void);
uint32_t hw_lcd_get_bus_freq_hz(void);
uint8_t hw_lcd_get_bus_data_lines(void);
uint8_t hw_lcd_get_bits_per_pixel(void);
