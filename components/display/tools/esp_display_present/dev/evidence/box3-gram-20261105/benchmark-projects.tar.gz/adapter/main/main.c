/*
 * SPDX-FileCopyrightText: 2023-2026 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: CC0-1.0
 */

/**
 * Official LVGL benchmark.
 *
 * RGB and MIPI panels walk the same tear-avoid modes and rotations that
 * lvgl_present_benchmark runs, one fresh display registration per case.
 * Other interfaces keep the single default-mode run.
 */

#include <inttypes.h>

#include "esp_err.h"
#include "esp_log.h"
#include "esp_lv_adapter.h"
#include "esp_timer.h"
#include "hw_init.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "lv_demos.h"
#include "sdkconfig.h"

static const char *TAG = "lvgl_adapter";

#define APP_BENCH_TIMEOUT_SECONDS 150

typedef struct {
    esp_lv_adapter_tear_avoid_mode_t mode;
    const char *name;
    uint8_t tiles;
    bool psram;
    bool supported;
} benchmark_mode_t;

typedef struct {
    bool complete;
    int32_t avg_fps;
    int32_t avg_cpu;
    int32_t avg_render_time;
    int32_t avg_flush_time;
    int32_t valid_scene_count;
} benchmark_result_t;

#if 1
static const benchmark_mode_t s_modes[] = {
    {ESP_LV_ADAPTER_TEAR_AVOID_MODE_NONE, "GRAM_T1_INTERNAL", 1, false, true},
    {ESP_LV_ADAPTER_TEAR_AVOID_MODE_NONE, "GRAM_T2_INTERNAL", 2, false, true},
    {ESP_LV_ADAPTER_TEAR_AVOID_MODE_NONE, "GRAM_T1_PSRAM", 1, true, true},
    {ESP_LV_ADAPTER_TEAR_AVOID_MODE_NONE, "GRAM_T2_PSRAM", 2, true, true},
    {ESP_LV_ADAPTER_TEAR_AVOID_MODE_NONE, "AUTO_T2_INTERNAL", 2, false, false},
    {ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_FULL, "DOUBLE_FULL", 1, false, false},
    {ESP_LV_ADAPTER_TEAR_AVOID_MODE_TRIPLE_FULL, "TRIPLE_FULL", 1, false, false},
    {ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_DIRECT, "DOUBLE_DIRECT", 1, false, false},
    {ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_PARTIAL, "DOUBLE_PARTIAL", 1, false, false},
    {ESP_LV_ADAPTER_TEAR_AVOID_MODE_TRIPLE_PARTIAL, "TRIPLE_PARTIAL", 1, false, false},
    {ESP_LV_ADAPTER_TEAR_AVOID_MODE_TE_SYNC, "TE_SYNC", 1, false, false},
};

static const esp_lv_adapter_rotation_t s_rotations[] = {
    ESP_LV_ADAPTER_ROTATE_0,
    ESP_LV_ADAPTER_ROTATE_90,
    ESP_LV_ADAPTER_ROTATE_180,
    ESP_LV_ADAPTER_ROTATE_270,
};

static benchmark_result_t s_result;
static benchmark_mode_t s_active_mode;
static esp_lv_adapter_rotation_t s_active_rotation;


static void benchmark_end_cb(const lv_demo_benchmark_summary_t *summary)
{
    s_result.valid_scene_count = summary->valid_scene_cnt;
    if (summary->valid_scene_cnt > 0) {
        s_result.avg_fps = summary->total_avg_fps / summary->valid_scene_cnt;
        s_result.avg_cpu = summary->total_avg_cpu / summary->valid_scene_cnt;
        s_result.avg_render_time =
            summary->total_avg_render_time / summary->valid_scene_cnt;
        s_result.avg_flush_time =
            summary->total_avg_flush_time / summary->valid_scene_cnt;
    }

    for (lv_demo_benchmark_scene_dsc_t *scene = summary->scenes;
            scene->create_cb != NULL; ++scene) {
        if (scene->measurement_cnt > 0) {
            ESP_LOGI(TAG,
                     "SCENE mode=%s te_buffers=0 rotation=%d name=\"%s\" "
                     "fps=%u cpu=%u%% render=%ums flush=%ums",
                     s_active_mode.name, (int)s_active_rotation,
                     scene->name,
                     (unsigned)(scene->fps_avg / scene->measurement_cnt),
                     (unsigned)(scene->cpu_avg_usage / scene->measurement_cnt),
                     (unsigned)(scene->render_avg_time / scene->measurement_cnt),
                     (unsigned)(scene->flush_avg_time / scene->measurement_cnt));
        }
        scene->cpu_avg_usage = 0;
        scene->fps_avg = 0;
        scene->render_avg_time = 0;
        scene->flush_avg_time = 0;
        scene->measurement_cnt = 0;
    }
    s_result.complete = true;
}

static bool wait_until_complete(uint32_t timeout_ms)
{
    const int64_t end_us = esp_timer_get_time() + (int64_t)timeout_ms * 1000;
    while (!s_result.complete && esp_timer_get_time() < end_us) {
        vTaskDelay(pdMS_TO_TICKS(20));
    }
    return s_result.complete;
}

static esp_lv_adapter_display_config_t display_config(
    esp_lcd_panel_handle_t panel,
    esp_lcd_panel_io_handle_t io,
    esp_lv_adapter_tear_avoid_mode_t mode,
    esp_lv_adapter_rotation_t rotation)
{
#if CONFIG_EXAMPLE_LCD_INTERFACE_MIPI_DSI
    esp_lv_adapter_display_config_t config = ESP_LV_ADAPTER_DISPLAY_MIPI_DEFAULT_CONFIG(
                panel, io, HW_LCD_H_RES, HW_LCD_V_RES, rotation);
#elif CONFIG_EXAMPLE_LCD_INTERFACE_RGB
    esp_lv_adapter_display_config_t config = ESP_LV_ADAPTER_DISPLAY_RGB_DEFAULT_CONFIG(
                panel, io, HW_LCD_H_RES, HW_LCD_V_RES, rotation);
#else
    esp_lv_adapter_display_config_t config = ESP_LV_ADAPTER_DISPLAY_SPI_WITH_PSRAM_DEFAULT_CONFIG(
                panel, io, HW_LCD_H_RES, HW_LCD_V_RES, rotation);
#endif
    config.tear_avoid_mode = mode;
    return config;
}

static void run_case(esp_lcd_panel_handle_t panel, esp_lcd_panel_io_handle_t io,
                     const benchmark_mode_t *test, esp_lv_adapter_rotation_t rotation)
{
    if (!test->supported || rotation != ESP_LV_ADAPTER_ROTATE_0) {
        ESP_LOGI(TAG, "SKIP mode=%s te_buffers=0 rotation=%d: %s", test->name, (int)rotation,
                 !test->supported ? "GRAM mode unavailable or TE not wired" : "adapter NONE does not implement software rotation");
        return;
    }
    s_result = (benchmark_result_t) {
        0
    };
    s_active_mode = *test;
    s_active_rotation = rotation;

    ESP_LOGI(TAG, "RUN mode=%s te_buffers=0 rotation=%d size=%ux%u timeout=%ds",
             test->name, (int)rotation, HW_LCD_H_RES, HW_LCD_V_RES,
             APP_BENCH_TIMEOUT_SECONDS);

    if (esp_lv_adapter_lock(-1) != ESP_OK) {
        ESP_LOGE(TAG, "SKIP mode=%s te_buffers=0 rotation=%d: adapter lock",
                 test->name, (int)rotation);
        return;
    }
    esp_lv_adapter_display_config_t config =
        display_config(panel, io, test->mode, rotation);
    config.profile.buffer_height = 50;
    config.profile.use_psram = test->psram;
    config.profile.require_double_buffer = test->tiles == 2;
    lv_display_t *disp = esp_lv_adapter_register_display(&config);
    if (disp == NULL) {
        esp_lv_adapter_unlock();
        ESP_LOGI(TAG, "SKIP mode=%s te_buffers=0 rotation=%d: register failed",
                 test->name, (int)rotation);
        return;
    }
    lv_demo_benchmark_set_end_cb(benchmark_end_cb);
    lv_demo_benchmark();
    esp_lv_adapter_unlock();

    const bool complete = wait_until_complete(APP_BENCH_TIMEOUT_SECONDS * 1000U);
    if (!complete) {
        ESP_LOGE(TAG, "benchmark timed out before LVGL summary");
    }

    if (esp_lv_adapter_lock(-1) == ESP_OK) {
        lv_obj_t *screen = lv_display_get_screen_active(disp);
        if (screen != NULL) {
            lv_obj_clean(screen);
        }
        esp_lv_adapter_unlock();
    }
    ESP_ERROR_CHECK(esp_lv_adapter_unregister_display(disp));

    if (!complete) {
        ESP_LOGE(TAG, "FAIL mode=%s te_buffers=0 rotation=%d: timeout",
                 test->name, (int)rotation);
        return;
    }
    ESP_LOGI(TAG,
             "PASS mode=%s te_buffers=0 rotation=%d frames=0 transport_fps=0.0 "
             "lvgl_fps=%" PRId32 " cpu=%" PRId32 "%% render=%" PRId32
             "ms flush=%" PRId32 "ms scenes=%" PRId32,
             test->name, (int)rotation, s_result.avg_fps,
             s_result.avg_cpu, s_result.avg_render_time, s_result.avg_flush_time,
             s_result.valid_scene_count);
}

static void run_matrix(void)
{
    esp_lcd_panel_handle_t panel = NULL;
    esp_lcd_panel_io_handle_t io = NULL;
    ESP_ERROR_CHECK(hw_lcd_init(&panel, &io, 3, HW_ROTATE_0));

    esp_lv_adapter_config_t adapter_cfg = ESP_LV_ADAPTER_DEFAULT_CONFIG();
    /* RGB full-frame flush overflows the 8 KB default on ESP32-S3. */
    adapter_cfg.task_stack_size = 24576;
    ESP_ERROR_CHECK(esp_lv_adapter_init(&adapter_cfg));
    ESP_ERROR_CHECK(esp_lv_adapter_start());

    printf("\r\n####################################################################\r\n");
    ESP_LOGI(TAG, "matrix round=1 start");
    for (size_t mode_index = 0; mode_index < sizeof(s_modes) / sizeof(s_modes[0]);
            ++mode_index) {
        for (size_t rotation_index = 0;
                rotation_index < sizeof(s_rotations) / sizeof(s_rotations[0]);
                ++rotation_index) {
            run_case(panel, io, &s_modes[mode_index], s_rotations[rotation_index]);
        }
    }
    ESP_LOGI(TAG, "matrix round=1 complete");
    ESP_LOGI(TAG, "single-run matrix complete; benchmark task stopped");
}
#endif /* MIPI DSI or RGB */

void app_main(void)
{
#if 1
    run_matrix();
#else
    example_lvgl_ctx_t ctx;
    ESP_ERROR_CHECK(example_lvgl_init(&ctx));
    ESP_LOGI(TAG, "Starting LVGL benchmark demo");
    if (esp_lv_adapter_lock(-1) == ESP_OK) {
        lv_demo_benchmark();
        esp_lv_adapter_unlock();
    }
#endif
}
