/* SPDX-FileCopyrightText: 2026 Espressif Systems (Shanghai) CO LTD
 * SPDX-License-Identifier: Apache-2.0 */
#include "esp_lcd_present_trace.h"
#include <string.h>
#include <stdbool.h>
#include <stdbool.h>
#include <stdio.h>
#include <inttypes.h>
#ifndef PRESENT_TRACE_HOST
#include "esp_attr.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#define TRACE_IRAM IRAM_ATTR
static portMUX_TYPE lock = portMUX_INITIALIZER_UNLOCKED;
#define ENTER() portENTER_CRITICAL_SAFE(&lock)
#define EXIT() portEXIT_CRITICAL_SAFE(&lock)
#define NOW() ((uint64_t)esp_timer_get_time())
#else
#define TRACE_IRAM
#define ENTER() ((void)0)
#define EXIT() ((void)0)
#define NOW() ((uint64_t)0)
#endif
#define SAVED_EVENTS 16
static struct {
    esp_lcd_present_trace_snapshot_t view;
    unsigned count;
    struct sample {
        uint64_t time_us;
        uint32_t request_seq, event_seq, kind;
        uintptr_t expected, observed, previous, raw;
    } samples[SAVED_EVENTS];
} trace;

void esp_lcd_present_trace_bind(void *panel, void *const *fbs, unsigned count, unsigned bounce_bytes, unsigned kind)
{
    ENTER();
    memset(&trace, 0, sizeof(trace));
    trace.view.panel = (uintptr_t)panel;
    trace.count = count > 3 ? 3 : count;
    for (unsigned i = 0; i < trace.count; ++i) {
        trace.view.fbs[i] = (uintptr_t)fbs[i];
    }
    trace.view.requested = trace.view.observed = trace.view.fbs[0];
    trace.view.bounce_bytes = bounce_bytes;
    trace.view.kind = kind;
    EXIT();
}

void TRACE_IRAM esp_lcd_present_trace_request(void *panel, unsigned index)
{
    ENTER();
    if ((uintptr_t)panel == trace.view.panel) {
        ++trace.view.requests;
        if (index >= trace.count) {
            ++trace.view.outside_pool;
        } else {
            if (trace.view.pending) {
                ++trace.view.superseded;
            }
            uintptr_t requested = trace.view.fbs[index];
            if (requested == trace.view.observed) {
                ++trace.view.active_submits;
                if (trace.view.saved < SAVED_EVENTS) {
                    trace.samples[trace.view.saved++] = (struct sample) {
                        NOW(), trace.view.requests, trace.view.events, 1, requested, trace.view.observed, trace.view.observed, 0
                    };
                }
            }
            trace.view.requested = requested;
            trace.view.pending = 1;
        }
    }
    EXIT();
}

void TRACE_IRAM esp_lcd_present_trace_event(void *panel, unsigned kind, unsigned expected, int observed, uintptr_t raw)
{
    uint64_t now = NOW();
    ENTER();
    if ((uintptr_t)panel == trace.view.panel) {
        ++trace.view.events;
        uintptr_t before = trace.view.observed;
        uintptr_t wanted = expected < trace.count ? trace.view.fbs[expected] : 0;
        uintptr_t actual = observed >= 0 && (unsigned)observed < trace.count ? trace.view.fbs[observed] : 0;
        bool suspicious = false;
        if (!actual) {
            ++trace.view.unresolved;
            suspicious = true;
        } else {
            if (wanted != actual) {
                ++trace.view.target_diffs;
                suspicious = true;
            }
            trace.view.observed = actual;
            if (actual == trace.view.requested) {
                trace.view.pending = 0;
            }
        }
        if (suspicious && trace.view.saved < SAVED_EVENTS) {
            trace.samples[trace.view.saved++] = (struct sample) {
                now, trace.view.requests, trace.view.events, kind, wanted, actual, before, raw
            };
        }
    }
    EXIT();
}

void TRACE_IRAM esp_lcd_present_trace_rgb_supply(void *panel, unsigned got, unsigned expected, unsigned restart)
{
    ENTER();
    if ((uintptr_t)panel == trace.view.panel) {
        if (!trace.view.supply_frames || got < trace.view.supply_min_eofs) trace.view.supply_min_eofs = got;
        ++trace.view.supply_frames;
        trace.view.supply_short += got < expected;
        trace.view.supply_restarts += restart != 0;
        trace.view.supply_expected = expected;
        if (trace.view.measuring == 1) {
            trace.view.measuring = 2; /* Discard the partial frame at RUN entry. */
        } else if (trace.view.measuring == 2) {
            ++trace.view.measured_frames;
            trace.view.measured_short += got < expected;
            trace.view.measured_restarts += restart != 0;
        }
    }
    EXIT();
}

void esp_lcd_present_trace_mark_running(unsigned running)
{
    ENTER(); trace.view.measuring = running != 0; EXIT();
}

void esp_lcd_present_trace_reset(void)
{
    esp_lcd_present_trace_integrity_reset();
    ENTER();
    esp_lcd_present_trace_snapshot_t old = trace.view;
    memset(&trace.view, 0, sizeof(trace.view));
    trace.view.panel = old.panel;
    for (unsigned i = 0; i < 3; ++i) {
        trace.view.fbs[i] = old.fbs[i];
    }
    trace.view.requested = old.requested;
    trace.view.observed = old.observed;
    trace.view.pending = old.pending;
    trace.view.bounce_bytes = old.bounce_bytes;
    trace.view.kind = old.kind;
    EXIT();
}
void esp_lcd_present_trace_snapshot(esp_lcd_present_trace_snapshot_t *out)
{
    ENTER(); *out = trace.view; EXIT();
}
void esp_lcd_present_trace_report(const char *mode, unsigned rotation)
{
    esp_lcd_present_trace_snapshot_t s;
    struct sample samples[SAVED_EVENTS];
    ENTER(); s = trace.view; memcpy(samples, trace.samples, sizeof(samples)); EXIT();
    printf("DRIVER_TRACE mode=%s rotation=%u kind=%u bounce_bytes=%u requests=%u events=%u superseded=%u active_submits=%u target_diffs=%u unresolved=%u outside_pool=%u pending=%u saved=%u fb0=0x%"PRIxPTR" fb1=0x%"PRIxPTR" fb2=0x%"PRIxPTR" requested=0x%"PRIxPTR" observed=0x%"PRIxPTR"\n", mode, rotation, (unsigned)s.kind, (unsigned)s.bounce_bytes, (unsigned)s.requests, (unsigned)s.events, (unsigned)s.superseded, (unsigned)s.active_submits, (unsigned)s.target_diffs, (unsigned)s.unresolved, (unsigned)s.outside_pool, (unsigned)s.pending, (unsigned)s.saved, s.fbs[0], s.fbs[1], s.fbs[2], s.requested, s.observed);
    printf("RGB_SUPPLY mode=%s rotation=%u frames=%u short_frames=%u restarts=%u min_eofs=%u expected_eofs=%u measured_frames=%u measured_short=%u measured_restarts=%u\n", mode, rotation, (unsigned)s.supply_frames, (unsigned)s.supply_short, (unsigned)s.supply_restarts, (unsigned)s.supply_min_eofs, (unsigned)s.supply_expected, (unsigned)s.measured_frames, (unsigned)s.measured_short, (unsigned)s.measured_restarts);
    esp_lcd_present_trace_integrity_report(mode, rotation);
    for (unsigned i = 0; i < s.saved; ++i) {
        struct sample *p = &samples[i];
        printf("DRIVER_TRACE_EVENT mode=%s rotation=%u us=%"PRIu64" request_seq=%u event_seq=%u kind=%u expected=0x%"PRIxPTR" observed=0x%"PRIxPTR" previous=0x%"PRIxPTR" raw=0x%"PRIxPTR"\n", mode, rotation, p->time_us, (unsigned)p->request_seq, (unsigned)p->event_seq, (unsigned)p->kind, p->expected, p->observed, p->previous, p->raw);
    }
}

#define BLOCKS 64
#define BAD_SAMPLES 12
static struct {
    struct { uint32_t a[BLOCKS], b[BLOCKS]; unsigned generation, count, block, busy; } fb[3];
    unsigned submissions, checked, changed, unknown, raced, invalid, source_changes, source, source_valid;
    unsigned sample_count;
    struct { uint64_t us; uintptr_t address; unsigned index, position, generation, expected_a, expected_b, actual_a, actual_b; } samples[BAD_SAMPLES];
} integrity;
/* Two independent order-sensitive 32-bit accumulators; probabilistic integrity
 * check, not a byte-for-byte proof. Every input word is read, no sampling. */
static void TRACE_IRAM fingerprint(const void *data, size_t bytes, uint32_t *a, uint32_t *b)
{
    const uint32_t *p=data; uint32_t x=0x9e3779b9, y=0x85ebca6b;
    for (size_t i=0;i<bytes/4;i++) { uint32_t w=p[i]; x=((x<<5)|(x>>27)) ^ w; y+=w ^ (uint32_t)i; y=(y<<7)|(y>>25); }
    const unsigned char *tail=(const unsigned char *)(p+bytes/4);
    for(size_t i=0;i<bytes%4;i++) {x=(x*33)^tail[i]; y+=tail[i];}
    *a=x;*b=y;
}
void esp_lcd_present_trace_integrity_reset(void) { ENTER(); memset(&integrity,0,sizeof(integrity)); EXIT(); }
void esp_lcd_present_trace_capture(void *panel, unsigned index, const void *pixels, size_t size, size_t block)
{
    uint32_t a[BLOCKS],b[BLOCKS];
    if (!block || size%block || size/block>BLOCKS || index>=3) { ENTER();++integrity.invalid;EXIT();return; }
    ENTER(); bool bound=(uintptr_t)panel==trace.view.panel; if(bound) ++integrity.fb[index].busy; EXIT();
    if(!bound)return;
    for(unsigned i=0;i<size/block;i++) fingerprint((const unsigned char*)pixels+i*block,block,&a[i],&b[i]);
    ENTER();
    memcpy(integrity.fb[index].a,a,size/block*sizeof(uint32_t));memcpy(integrity.fb[index].b,b,size/block*sizeof(uint32_t));
    integrity.fb[index].block=block;integrity.fb[index].count=size/block;++integrity.fb[index].generation;--integrity.fb[index].busy;++integrity.submissions;
    EXIT();
}
unsigned TRACE_IRAM esp_lcd_present_trace_copy_begin(void *panel,unsigned index,unsigned position)
{
    unsigned token=0; ENTER();
    if((uintptr_t)panel==trace.view.panel && trace.view.measuring==2) {
        if(index>=trace.count)++integrity.invalid;
        else {
            if(!position){integrity.source=index;integrity.source_valid=1;}
            else if(integrity.source_valid && integrity.source!=index)++integrity.source_changes;
            if(!integrity.fb[index].busy)token=integrity.fb[index].generation;
        }
    }
    EXIT();return token;
}
void TRACE_IRAM esp_lcd_present_trace_copy_end(void *panel,unsigned index,unsigned position,unsigned token,const void *copied,size_t bytes)
{
    if(!token){ENTER();if((uintptr_t)panel==trace.view.panel && trace.view.measuring==2)++integrity.unknown;EXIT();return;}
    uint32_t a,b;fingerprint(copied,bytes,&a,&b);
    ENTER();
    if((uintptr_t)panel==trace.view.panel && trace.view.measuring==2 && index<trace.count) {
        unsigned block=integrity.fb[index].block,slot=block?position/block:BLOCKS;
        if(integrity.fb[index].generation!=token || integrity.fb[index].busy)++integrity.raced;
        else if(slot>=integrity.fb[index].count || bytes!=block || position%block)++integrity.invalid;
        else {
            ++integrity.checked;
            if(a!=integrity.fb[index].a[slot] || b!=integrity.fb[index].b[slot]) {
                ++integrity.changed;
                if(integrity.sample_count<BAD_SAMPLES) {
                    unsigned j=integrity.sample_count++;integrity.samples[j].us=NOW();integrity.samples[j].address=trace.view.fbs[index];integrity.samples[j].index=index;integrity.samples[j].position=position;integrity.samples[j].generation=token;
                    integrity.samples[j].expected_a=integrity.fb[index].a[slot];integrity.samples[j].expected_b=integrity.fb[index].b[slot];integrity.samples[j].actual_a=a;integrity.samples[j].actual_b=b;
                }
            }
        }
    }
    EXIT();
}
void esp_lcd_present_trace_integrity_report(const char *mode,unsigned rotation)
{
    /* Called only after panel close: no writer remains. */
    printf("RGB_INTEGRITY mode=%s rotation=%u submissions=%u checked=%u changed=%u unknown=%u raced=%u invalid=%u source_changes=%u samples=%u\n",mode,rotation,integrity.submissions,integrity.checked,integrity.changed,integrity.unknown,integrity.raced,integrity.invalid,integrity.source_changes,integrity.sample_count);
    for(unsigned i=0;i<integrity.sample_count;i++)printf("RGB_INTEGRITY_EVENT mode=%s rotation=%u us=%"PRIu64" address=0x%"PRIxPTR" index=%u byte_offset=%u generation=%u expected=%08x:%08x actual=%08x:%08x\n",mode,rotation,integrity.samples[i].us,integrity.samples[i].address,integrity.samples[i].index,integrity.samples[i].position,integrity.samples[i].generation,integrity.samples[i].expected_a,integrity.samples[i].expected_b,integrity.samples[i].actual_a,integrity.samples[i].actual_b);
}
