from pathlib import Path
import json,subprocess,time,sys,traceback
r=Path('/tmp/present-s3-xip-on-light-20261110');runner='/tmp/present-s3-on-integrity-source-20261110/components/display/tools/esp_display_present/dev/tools/run.py';state={'stage':'flash','success':False,'scope':'present DOUBLE_FULL 0 complete16scenes only; no claim whole-suite complete'}
def save(): (r/'controller.json').write_text(json.dumps(state,indent=2)+'\n')
save()
try:
 cmd=[sys.executable,runner,'flash','--board','s3-rgb','--suite','benchmark','--implementation','present','--xip','on','--work-root',str(r),'--driver-trace',str(r/'driver-overlay'),'--port','/dev/ttyUSB1']
 with (r/'single-flash.log').open('w') as f:subprocess.run(cmd,check=True,stdout=f,stderr=subprocess.STDOUT,timeout=180)
 import serial
 from esptool.reset import HardReset
 state['stage']='capture';save();port=serial.Serial(port=None,baudrate=115200,timeout=.2);port.dtr=port.rts=False;port.port='/dev/ttyUSB1';port.open();HardReset(port)();buf=b'';start=time.monotonic()
 with port,(r/'single-live.log').open('wb') as f:
  while time.monotonic()-start<180:
   data=port.read(port.in_waiting or 1);f.write(data);f.flush();buf+=data
   if b'PASS mode=DOUBLE_FULL te_buffers=0 rotation=0' in buf:break
  else:raise RuntimeError('case timed out')
 text=buf.decode(errors='replace');assert text.count('SCENE mode=DOUBLE_FULL rotation=0 name=')==16
 state['success']=True;state['stage']='done';save();print('baseline done',flush=True)
except BaseException as e:state['error']=repr(e);state['stage']='failed';save();raise
