## Unreleased — V2 default implementation

- Keep the existing public API and component name; route through V2.
- Remove the superseded V1 implementation and private-source dependencies.
- See `../esp_display_present_v2/DEFAULT_SWITCH.md` for scope and validation.

# Changelog

## 0.1.2 - 2026-10-09

- Fix borrowed buffer alignment, capacity, color format and stride.

## 0.1.1 - 2026-09-30

- Scope IDF atomic-helper warning compatibility to LVGL's FreeRTOS source so
  standalone presenter examples do not need the full LVGL adapter.

## 0.1.0 - 2026-09-04

- Host the component in esp-iot-solution under `components/display/tools/esp_lv_present`.
- Relicense the component to Apache-2.0.
- Add a Unity test app and point examples at `lvgl_present_benchmark` and
  `gsp_lvgl_present_handoff`.
