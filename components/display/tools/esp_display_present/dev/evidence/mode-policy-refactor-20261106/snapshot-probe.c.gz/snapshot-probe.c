#include "support/legacy_panel.h"
static void report(unsigned id, const esp_display_present_plan_config_t *config, esp_err_t error)
{
    printf("%u %d", id, error);
    if (error == ESP_OK) {
        esp_display_present_resolved_plan_t p;
        esp_err_t e = esp_display_present_plan_resolve(config, &p);
        printf(" %d", e);
        if (e == ESP_OK) {
            printf(" %d %d %d %zu %zu %zu %zu %zu %zu %zu %zu %zu %zu %zu %u %u %u %u %u %u %d %d %d %d %d %d",
                   p.normalized.backend_kind, p.normalized.mode, p.normalized.backend.render_contract,
                   p.tiles.count, p.images.count, p.logical.count, p.conversion.count,
                   p.tiles.bytes_each, p.images.bytes_each, p.logical.bytes_each, p.conversion.bytes_each,
                   p.pixel_bytes, p.metadata_bytes, p.required_bytes,
                   p.logical_layout.width, p.logical_layout.height, p.physical_layout.width, p.physical_layout.height,
                   p.pending_runtime, (unsigned)p.tx_capacity, p.normalized.backend.rotation,
                   p.normalized.backend.active_writes, p.normalized.background_service,
                   p.normalized.backend.async_copy, p.normalized.backend.tx_staging, p.normalized.backend.in_place);
        }
    }
    putchar('\n');
}
int main(void)
{
    unsigned id = 0;
    struct fake_lcd panel = {0};
    for (unsigned code = 0; code < 55296; ++code) {
        unsigned v = code;
        esp_display_presenter_config_t c = config(&panel, true);
        c.target.hw.panel_type = v % 4; v /= 4;
        c.target.fb.mode = v % 8; v /= 8;
        c.target.hw.rotation = (v % 4) * 90; v /= 4;
        unsigned te = v % 3; v /= 3;
        c.target.hw.te_enabled = te != 0;
        c.target.hw.te_sync.gpio_num = te == 2 ? -1 : 0;
        c.target.fb.frame_buffer_count = v % 4; v /= 4;
        c.target.drawbuf.buffers = v % 3; v /= 3;
        c.target.drawbuf.te_compose_buffers = v % 3; v /= 3;
        c.pixel_format = c.target.hw.input_pixel_format = v % 2; v /= 2;
        c.target.hw.io = v % 2 ? &panel : NULL;
        c.target.drawbuf.in_psram = c.pixel_format == ESP_DISPLAY_PRESENT_PIXEL_FORMAT_RGB888;
        uint8_t count;
        esp_err_t q = esp_display_present_get_required_frame_buffer_count(&c.target, &count);
        printf("q %u %d %u\n", id, q, count);
        esp_display_present_plan_config_t plan;
        esp_err_t e = present_resources_plan(&c, true, &plan);
        if (e == ESP_OK) {
            plan.output = (esp_display_present_output_caps_t){.internal_dma = true, .ext_mem = true, .tight_stride = true};
        }
        report(id++, &plan, e);
    }
    for (unsigned code = 0; code < 6912; ++code) {
        unsigned v = code;
        esp_display_present_plan_config_t p = {.presenter = {.backend = {.width = 8, .height = 4, .tile_rows = 2, .max_frames = 4, .active_writes = true}},
                                               .output = {.internal_dma = true, .ext_mem = true, .tight_stride = true}};
        p.presenter.backend_kind = v % 3; v /= 3;
        p.presenter.mode = v % 9; v /= 9;
        p.presenter.backend.buffer_count = 1 + v % 4; v /= 4;
        p.presenter.backend.rotation = v % 4; v /= 4;
        if (v % 2) { static void *buffers[4]; p.presenter.backend.ext_bufs = buffers; p.presenter.backend.ext_bytes = 64; } v /= 2;
        p.te_enabled = v % 2; v /= 2;
        p.defaults = v % 2; v /= 2;
        if (v % 2) {p.presenter.backend.te_window_us = 1000; p.presenter.backend.te_budget_us = 100;}
        report(id++, &p, ESP_OK);
    }
    return 0;
}
