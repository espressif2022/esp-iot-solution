/*
 * SPDX-FileCopyrightText: 2026 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */

/* Runtime matrix for presentation modes supported by the initialized panel.
 * Each case owns a fresh presenter and LVGL display. */

#include <inttypes.h>

#include "esp_display_present.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "board_qspi.h"
#define HW_LCD_H_RES 480
#define HW_LCD_V_RES 480
void meter_reset(void);
void meter_report(const char *label);

#include "demos/lv_demos.h"
#include "lvgl.h"
#include "esp_lv_present.h"

static const char *TAG = "lvgl_bench";

/* LVGL worker: prio 6, no core affinity, 1ms min delay. */
#define LVGL_BENCHMARK_TICK_MS 1
#define LVGL_BENCHMARK_TASK_PRIO 6
#define LVGL_BENCHMARK_TASK_STACK 24576

#define APP_BENCH_QUIESCE_TIMEOUT_MS 2000

typedef struct {
    esp_display_present_mode_t mode;
    uint8_t te_compose_buffers;
    const char *name;
    uint8_t tiles;
    bool psram;
} benchmark_mode_t;

typedef struct {
    bool complete;
    int32_t avg_fps;
    int32_t avg_cpu;
    int32_t avg_render_time;
    int32_t avg_flush_time;
    int32_t valid_scene_count;
} benchmark_result_t;

static const benchmark_mode_t s_modes[] = {
 {ESP_DISPLAY_PRESENT_MODE_TE_SYNC, 1, "TE_C1_T1", 1, false},
 {ESP_DISPLAY_PRESENT_MODE_TE_SYNC, 1, "TE_C1_T2", 2, false},
 {ESP_DISPLAY_PRESENT_MODE_TE_SYNC, 2, "TE_C2_T1", 1, false},
 {ESP_DISPLAY_PRESENT_MODE_TE_SYNC, 2, "TE_C2_T2", 2, false},
};
static const esp_display_present_rotation_t s_rotations[] = {ESP_DISPLAY_PRESENT_ROTATE_0, ESP_DISPLAY_PRESENT_ROTATE_90};
static benchmark_result_t s_result;
static benchmark_mode_t s_active_mode;
static esp_display_present_rotation_t s_active_rotation;


static esp_err_t get_case_frame_buffer_count(
    const esp_display_present_target_config_t *target,
    const benchmark_mode_t *test,
    esp_display_present_rotation_t rotation,
    uint8_t *out_count)
{
    esp_display_present_target_config_t config = *target;
    config.fb.mode = test->mode;
    config.hw.rotation = rotation;
    return esp_display_present_get_required_frame_buffer_count(&config, out_count);
}

static void benchmark_end_cb(const lv_demo_benchmark_summary_t *summary)
{
    s_result.valid_scene_count = summary->valid_scene_cnt;
    if (summary->valid_scene_cnt > 0) {
        s_result.avg_fps = summary->total_avg_fps / summary->valid_scene_cnt;
        s_result.avg_cpu = summary->total_avg_cpu / summary->valid_scene_cnt;
        s_result.avg_render_time =
            summary->total_avg_render_time / summary->valid_scene_cnt;
        s_result.avg_flush_time =
            summary->total_avg_flush_time / summary->valid_scene_cnt;
    }

    /* LVGL 9.5 resets scene_act but not these static accumulators when
     * lv_demo_benchmark() is called again. Copy the summary first, then make
     * the next matrix case independent from this one. */
    for (lv_demo_benchmark_scene_dsc_t *scene = summary->scenes;
            scene->create_cb != NULL; ++scene) {
        if (scene->measurement_cnt > 0) {
            ESP_LOGI(TAG,
                     "SCENE mode=%s te_buffers=%u rotation=%d name=\"%s\" "
                     "fps=%u cpu=%u%% render=%ums flush=%ums",
                     s_active_mode.name,
                     s_active_mode.te_compose_buffers,
                     (int)s_active_rotation, scene->name,
                     (unsigned)(scene->fps_avg / scene->measurement_cnt),
                     (unsigned)(scene->cpu_avg_usage /
                                scene->measurement_cnt),
                     (unsigned)(scene->render_avg_time /
                                scene->measurement_cnt),
                     (unsigned)(scene->flush_avg_time /
                                scene->measurement_cnt));
        }
        scene->cpu_avg_usage = 0;
        scene->fps_avg = 0;
        scene->render_avg_time = 0;
        scene->flush_avg_time = 0;
        scene->measurement_cnt = 0;
    }
    s_result.complete = true;
}

static void logical_size(esp_display_present_rotation_t rotation,
                         uint16_t *width, uint16_t *height)
{
    if (rotation == ESP_DISPLAY_PRESENT_ROTATE_90 ||
            rotation == ESP_DISPLAY_PRESENT_ROTATE_270) {
        *width = HW_LCD_V_RES;
        *height = HW_LCD_H_RES;
    } else {
        *width = HW_LCD_H_RES;
        *height = HW_LCD_V_RES;
    }
}

static void pump_lvgl_for(uint32_t duration_ms)
{
    const int64_t end_us = esp_timer_get_time() +
                           (int64_t)duration_ms * 1000;
    while (esp_timer_get_time() < end_us) {
        uint32_t delay_ms = lv_timer_handler();
        if (delay_ms == LV_NO_TIMER_READY) {
            delay_ms = LVGL_BENCHMARK_TICK_MS;
        } else if (delay_ms > 500) {
            delay_ms = 500;
        }
        if (delay_ms == 0) {
            taskYIELD();
        } else {
            vTaskDelay(pdMS_TO_TICKS(delay_ms));
        }
    }
}

static bool pump_lvgl_until_complete(uint32_t timeout_ms)
{
    const int64_t end_us = esp_timer_get_time() + (int64_t)timeout_ms * 1000;
    while (!s_result.complete && esp_timer_get_time() < end_us) {
        pump_lvgl_for(LVGL_BENCHMARK_TICK_MS);
    }
    return s_result.complete;
}

static esp_err_t run_case(
    const esp_display_present_target_config_t *base,
    const benchmark_mode_t *test,
    esp_display_present_rotation_t rotation)
{
    esp_display_present_target_config_t display = *base;
    display.fb.mode = test->mode;
    display.drawbuf.lines = 50;
    display.drawbuf.buffers = test->tiles;
    display.drawbuf.in_psram = test->psram;
    display.drawbuf.te_compose_buffers = test->te_compose_buffers;
    display.hw.rotation = rotation;

    uint16_t width = 0;
    uint16_t height = 0;
    logical_size(rotation, &width, &height);
    const esp_display_presenter_config_t config = {
        .width = width,
        .height = height,
        .pixel_format = display.hw.input_pixel_format,
        .max_damage_areas = 32,
        .target = display,
    };
    esp_display_presenter_t *presenter = NULL;
    esp_err_t ret = esp_display_presenter_create(&config, &presenter);
    if (ret != ESP_OK) {
        return ret;
    }

    lv_display_t *disp = NULL;
    ret = esp_lv_present_start(presenter, &disp);
    if (ret != ESP_OK) {
        (void)esp_display_presenter_delete(presenter);
        return ret;
    }
    s_result = (benchmark_result_t) {
        0
    };
    s_active_mode = *test;
    s_active_rotation = rotation;
    lv_demo_benchmark_set_end_cb(benchmark_end_cb);
    meter_reset();
    lv_demo_benchmark();
    lv_obj_invalidate(lv_display_get_screen_active(disp));

    ESP_LOGI(TAG,
             "RUN mode=%s te_buffers=%u rotation=%d size=%ux%u timeout=%ds",
             test->name, test->te_compose_buffers, (int)rotation,
             width, height, CONFIG_APP_LVGL_BENCH_TIMEOUT_SECONDS);
    const int64_t start_us = esp_timer_get_time();
    const bool complete = pump_lvgl_until_complete(
                              CONFIG_APP_LVGL_BENCH_TIMEOUT_SECONDS * 1000U);
    const int64_t elapsed_us = esp_timer_get_time() - start_us;
    const uint32_t frames = esp_lv_present_get_frame_count();

    if (!complete) {
        ESP_LOGE(TAG, "benchmark timed out before LVGL summary");
    }

    ESP_ERROR_CHECK(esp_display_presenter_quiesce(
                        presenter, APP_BENCH_QUIESCE_TIMEOUT_MS));
    meter_report(test->name);
    ESP_ERROR_CHECK(esp_lv_present_stop());
    ESP_ERROR_CHECK(esp_display_presenter_delete(presenter));

    if (!complete) {
        return ESP_ERR_TIMEOUT;
    }

    const double fps = elapsed_us > 0
                       ? (double)frames * 1000000.0 / (double)elapsed_us : 0.0;
    ESP_LOGI(TAG,
             "PASS mode=%s te_buffers=%u rotation=%d frames=%u transport_fps=%.1f "
             "lvgl_fps=%" PRId32 " cpu=%" PRId32 "%% render=%" PRId32
             "ms flush=%" PRId32 "ms scenes=%" PRId32,
             test->name, test->te_compose_buffers, (int)rotation,
             (unsigned)frames, fps, s_result.avg_fps, s_result.avg_cpu,
             s_result.avg_render_time, s_result.avg_flush_time,
             s_result.valid_scene_count);
    return ESP_OK;
}

static void lvgl_benchmark_task(void *arg)
{
    const esp_display_present_target_config_t *display = arg;
    unsigned round = 0;
    for (;;) {
        ++round;
        printf("\r\n####################################################################\r\n");
        ESP_LOGI(TAG, "matrix round=%u start", round);
        for (size_t mode_index = 0;
                mode_index < sizeof(s_modes) / sizeof(s_modes[0]);
                ++mode_index) {
            for (size_t rotation_index = 0;
                    rotation_index <
                    sizeof(s_rotations) / sizeof(s_rotations[0]);
                    ++rotation_index) {
                const benchmark_mode_t *test = &s_modes[mode_index];
                const esp_display_present_rotation_t rotation =
                    s_rotations[rotation_index];
                uint8_t frame_buffer_count = 0;
                esp_err_t ret = get_case_frame_buffer_count(
                                    display, test, rotation, &frame_buffer_count);
                if (ret == ESP_ERR_NOT_SUPPORTED) {
                    ESP_LOGI(TAG,
                             "SKIP mode=%s te_buffers=%u rotation=%d: "
                             "outside target capability matrix",
                             test->name, test->te_compose_buffers,
                             (int)rotation);
                    continue;
                }
                ESP_ERROR_CHECK(ret);
                ret = run_case(display, test, rotation);
                if (ret == ESP_ERR_NOT_SUPPORTED) {
                    ESP_LOGI(TAG,
                             "SKIP mode=%s te_buffers=%u rotation=%d: "
                             "driver rejected configuration",
                             test->name, test->te_compose_buffers,
                             (int)rotation);
                    continue;
                }
                ESP_ERROR_CHECK(ret);
            }
        }
        ESP_LOGI(TAG, "matrix round=%u complete", round);
#ifndef CONFIG_APP_LVGL_BENCH_LOOP
        ESP_LOGI(TAG, "single-run matrix complete; benchmark task stopped");
        vTaskDelete(NULL);
        return;
#endif
    }
}

static uint32_t tick_ms(void) { return (uint32_t)(esp_timer_get_time()/1000); }
void app_main(void)
{
    static esp_display_present_target_config_t display;
    esp_lcd_panel_handle_t panel = NULL;
    esp_lcd_panel_io_handle_t io = NULL;
    ESP_ERROR_CHECK(qspi_board_create(&panel, &io));
    display = (esp_display_present_target_config_t){
      .hw = {.panel=panel, .io=io, .panel_type=ESP_DISPLAY_PRESENT_PANEL_IO,
       .input_pixel_format=ESP_DISPLAY_PRESENT_PIXEL_FORMAT_RGB565,
       .swap_bytes=true, .spi_psram_dma_direct=true, .te_enabled=true,
       .te_sync={.gpio_num=QSPI_TE_GPIO, .bus_freq_hz=40000000, .data_lines=4}},
      .fb={.mode=ESP_DISPLAY_PRESENT_MODE_TE_SYNC},
    };
    lv_init();
    lv_tick_set_cb((lv_tick_get_cb_t)tick_ms);
    BaseType_t ok=xTaskCreate(lvgl_benchmark_task,"lv_bench",LVGL_BENCHMARK_TASK_STACK,&display,LVGL_BENCHMARK_TASK_PRIO,NULL);
    ESP_ERROR_CHECK(ok==pdPASS?ESP_OK:ESP_ERR_NO_MEM);
}
