# ChangeLog

## v0.7.4 (2026-10-28)

* Fix the LVGL v9 flush deadlock when LVGL invokes the flush from a task other than the adapter task. v9 pipeline waits block on bridge-owned semaphores, so a flush no longer clears or increments the calling task's notification index 0. The frame-complete ISR wakes the registered flush and dummy-draw waiters; v8 still uses task notifications. Covers `pipeline_blit()`, `wait_free_buf()`, buffer-switch wait, and GPIO TE completion.
* Add lvgl9 regressions for repeated synchronous refreshes from a non-adapter task, and for dummy-draw running concurrently with flush.

## v0.7.3~1 (2026-10-15)

* Use the local button component in benchmark and test app manifests for reproducible CI builds; adapter behavior is unchanged.

## v0.7.3 (2026-10-09)

* Fix LVGL 8/9 tear-avoid submission races, sequence wrap and early RGB completion.
* Validate framebuffer setup and complete LVGL 8 callback forwarding.
* Fix dummy draw completion, waiter lifetime and mode handoff.

## v0.7.2 (2026-09-29)

* Fix the LVGL FreeRTOS PSRAM-stack hook for LVGL 9.6's ESP-qualified `freertos/atomic.h` include while retaining compatibility with older LVGL 9 releases.

## v0.7.1 (2026-09-18)

* Add LVGL 9.6 compatibility for public/private headers, FreeType integration, and display color-format detection.
* Keep the existing LVGL v8 and v9 bridge paths and compatibility range.
* Require ESP-IDF >= 5.5.5.

## v0.7.0 (2026-08-14)

* Add a high-performance TE pipeline to improve rendering and display transfer efficiency while retaining TE synchronization.
* Fix LVGL v8/v9 rotation with flash encryption or PSRAM ECC enabled.
* Fix TE transfer error handling and ISR logging.

## v0.6.4 (2026-08-12)

* Fix the required framebuffer count for 180° rotation in `DOUBLE_FULL` and `DOUBLE_DIRECT` modes.

## v0.6.3 (2026-07-17)

* Optimize LVGL v8/v9 partial framebuffer repair for double/triple-buffer tear-avoid modes:
  - Track per-framebuffer pending dirty regions and repair only `pending[target] - current_dirty`
  - Support rotated partial refresh by converting LVGL dirty areas to physical framebuffer coordinates
  - Keep baseline repair fallback for reset, stale history, framebuffer-index mismatch, or repair-region overflow

## v0.6.2 (2026-07-03)

* Add `esp_lv_adapter_display_notify_frame_buf_complete_from_isr()` to forward an LCD frame-buffer-complete event into the adapter's buffer-switch/pipeline release path from an ISR. This closes a gap in the external-callback-driven flow: when an external owner holds the ESP-IDF panel callbacks (after `esp_lv_adapter_set_default_display_idf_callback_registration_enabled(false)`), the existing `notify_color_trans_done_from_isr`/`notify_frame_done_from_isr` forwarders never release pipeline buffers, so buffer-switch tear-avoid modes and dummy-draw could block forever in the flush path waiting for a free buffer.
  - Add `notify_frame_buf_complete_from_isr` to the display-bridge vtable and implement it in the LVGL v9 bridge (routes to the shared frame-buffer-switch handler)
  - Add `display_manager_notify_frame_buf_complete_from_isr()` wrapper

## v0.6.1 (2026-06-29)

* Replace IDF version-number guards with header/symbol-based feature detection in CMake:
  - `ESP_ASYNC_COLOR_CONVERT_AVAILABLE`: probed by checking for `esp_driver_dma/include/esp_async_color_convert.h`; replaces `ESP_IDF_VERSION >= 6.2.0` guards throughout the DMA2D paths
  - `ESP_LCD_DPI_HAS_FRAME_BUF_COMPLETE_CB`: probed by searching for `esp_lcd_dpi_panel_frame_buf_complete_cb_t` in `esp_lcd_mipi_dsi.h`; replaces the `IDF_VERSION_MAJOR == 6 && IDF_VERSION_MINOR == 0` guard for `on_frame_buf_complete` vs `on_refresh_done`
  - `bootloader_support` dependency: probed by checking for `esp_efuse_is_flash_encryption_enabled` in `esp_efuse.h`; avoids the component on IDF versions that expose the API directly
* Add `#warning` build diagnostic when `on_frame_buf_complete` is unavailable, alerting that buffer-switch release and dummy-draw require an IDF update

## v0.6.0 (2026-06-25)

* Fix flash encryption API version guard boundary: switch the `esp_efuse_is_flash_encryption_enabled()` branch to IDF >= 6.0.1, falling back to `esp_flash_encryption_enabled()` below it, so both the `v6.0` tag (6.0.0) and the `release/v6.0` branch (6.0.1) compile

## v0.6.0-beta (2026-06-23)

* Unify anti-tearing ISR handling around `on_frame_buf_complete` for accurate buffer-switch synchronization
* Add tear-free dummy draw pipeline APIs: `esp_lv_adapter_dummy_draw_get_free_buf()` and `esp_lv_adapter_dummy_draw_flush_buf()`
* Update the dummy draw example to use the buffer-switch pipeline when available
* **Breaking change**: remove `on_vsync` and `on_color_trans_done` from `esp_lv_adapter_dummy_draw_callbacks_t`; use the dummy draw pipeline APIs instead

## v0.5.3 (2026-06-22)

* Set DMA2D burst size to 128 bytes for maximum PSRAM throughput on IDF >= 6.2
* Fix flash encryption API version guard: use `esp_efuse_is_flash_encryption_enabled()` on IDF >= 6.0, `esp_flash_encryption_enabled()` on older versions
* Fix `bootloader_support` CMake dependency: only link on IDF < 6.0; add `esp_driver_dma` for IDF >= 6.2
* Mark auto sleep state as `volatile` to prevent compiler optimization across task/ISR boundaries

## v0.5.2 (2026-06-09)

* Add LVGL v9 PPA acceleration for RGB888 displays: ARGB8888 per-pixel alpha blend and opaque fill paths; opaque RGB565/RGB888 images fall back to CPU to preserve tiled image rendering
* Fix framebuffer cache sync to use the destination pixel size (2 for RGB565, 3 for RGB888) instead of `sizeof(lv_color_t)`
* Guard PPA source bounds on the custom-handler path to avoid reads outside the source image
* Add bypass mode for adapter-managed ESP-IDF LCD and touch callbacks with public `notify_from_isr` entry points
* Fix TE vsync wait deadlock by replacing `portMAX_DELAY` with a bounded timeout (6× TE period, clamped to [20ms, 1000ms])
* Fix stale DMA completion race by moving `ulTaskNotifyValueClear()` before `esp_lcd_panel_draw_bitmap()`
* Add `CONFIG_ESP_LVGL_ADAPTER_FREETYPE_MINIMAL_BUILD` to reduce FreeType flash footprint
* Fix IRAM coverage of `from_isr` display and touch notification call chain
* Add LVGL v9 multi-control touch mode for independent control of discrete widgets, plus parameter validation and cleanup handling updates

## v0.5.1 (2026-05-21)

* Add optional FreeType render pool reduction for lower stack usage
* Add optional LVGL FreeRTOS thread stack allocation in PSRAM
* Relax LVGL v9's conservative 32KB FreeType draw-stack diagnostic when the small render pool is enabled
* Simplify optional dependency linking with `idf_component_optional_requires`

## v0.5.0 (2026-05-09)

* Add draw bitmap and touch callback hooks for external display/input adaptation
* Improve cache synchronization for accelerated display paths
* Update the PPA hang workaround patch and documentation for ESP-IDF `tags/v6.0`

## v0.4.3 (2026-04-03)

* Fix `pause()` / `resume()` handling so the internal `LVGL tick` timer is stopped during pause and restarted during resume
* Update sleep management documentation for tickless auto Light Sleep usage

## v0.4.2 (2026-03-31)

* Add `ESP_LV_ADAPTER_TEAR_AVOID_MODE_DOUBLE_PARTIAL` for double-buffer partial refresh
* Add `ESP_LVGL_ADAPTER_PARTIAL_AUX_IMG_CACHE` to increase LVGL image cache in partial tear-avoid modes

## v0.4.1 (2026-03-12)

* Fix refresh issue when LV_DRAW_BUF_STRIDE_ALIGN > 1 in LVGL v9 bridge
* Fix resource leaks and use-after-free risks in deinit path (flush-wait, task stack, VSync callbacks, lv_deinit)

## v0.4.0 (2026-02-11)

* Add multi-touch adaptation support
* Add ESP-IDF v6.0 compatibility updates

## v0.3.2 (2026-01-22)

* Fix C++ designated initializer order in SPI-with-PSRAM display profile macros

## v0.3.1 (2026-01-07)

* Fix monochrome SPI default display macro to use the correct profile macro

## v0.3.0 (2026-01-07)

* Added monochrome display support for LVGL v8 and v9
* Add migration guide from esp_lvgl_port to esp_lvgl_adapter
* Reverted conditional dependency management

## v0.2.0 (2025-12-24)

* Optimized dependency management by adding conditional rules for optional dependencies

## v0.1.4 (2025-12-22)

* Fixed the LVGL naming compatibility dependency issue

## v0.1.3 (2025-12-16)

* Fixed the issue with 180-degree rotation

## v0.1.2 (2025-12-12)

* Prevent deadlock when pausing the adapter from the LVGL worker

## v0.1.1 (2025-12-10)

* Improved the screen update failure handling mechanism

## v0.1.0 (2025-11-17)

* Add a sleep mechanism compatible with Light Sleep
* Add a TE-based anti-tearing mechanism

## v0.1.0-beta.2 (2025-11-4)

* Fix a crash that occurred in some cases when PPA acceleration was enabled

## v0.1.0-beta.1 (2025-10-27)

* Support for LVGL v8.x and v9.x with unified API
* Unified display registration for MIPI DSI, RGB, QSPI, SPI, I2C, I80 interfaces
* Multiple buffering modes and screen rotation support (0°/90°/180°/270°)
* Tearing effect avoidance for RGB and MIPI DSI displays
* PPA hardware acceleration support for ESP32-P4
* Thread-safe LVGL access with lock/unlock APIs
* Input device support: touch screen, button navigation, rotary encoder
* Optional filesystem bridge integration (esp_lv_fs)
* Optional image decoder support (esp_lv_decoder)
* Optional FreeType font rendering support
* FPS statistics and Dummy Draw mode
* API naming aligned with esp_lv_decoder and esp_lv_fs for consistency
